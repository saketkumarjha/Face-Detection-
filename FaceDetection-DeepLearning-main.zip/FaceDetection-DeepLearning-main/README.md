About
This a face dectection deep learning project I built at the end of december 2023. It was a final project for a Machine Learning class. Final Grade : A

Video : https://www.youtube.com/watch?v=SOQPcO0Lxoo
